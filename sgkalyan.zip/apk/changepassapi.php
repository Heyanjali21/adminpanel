<?php


$uniqueToken =  isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '';
                
    $oldPassword = $_POST["old_pass"];
    $newPassword = $_POST["new_pass"];
    $confirmPassword = $_POST["confirmPassword"];
  
    

    
   
    $data = [
        'old_pass' => $oldPassword,
        'new_pass' => $newPassword,
        'confirmPassword' => $confirmPassword,
        'env_type' => 'Prod',
        'app_key' => 'HbegvJLeKwSFyApopniGHHBTZPocyH',
        'unique_token' => $uniqueToken,
    
     
    ];
    
  
    $jsonData = json_encode($data);
    
   
    $apiUrl = 'https://disawar.techwarezen.shop/admin/api-change-password';
    
    
    $ch = curl_init($apiUrl);
    
    
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($jsonData),
    ]);
    
    
    $response = curl_exec($ch);
    
    
    if (curl_errno($ch)) {
        echo 'Curl error: ' . curl_error($ch);
    }
    
   
    curl_close($ch);
    
    
    echo $response;
    ?>
    