<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <title>Forgot Password</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .container {
            background-color: #7b0323;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 30px;
            /* Increase the border-radius value */
        }

        .forgot-password-form {
            max-width: 400px;
            margin: 0 auto;
            text-align: center;
            border-radius: 8px;
            /* Increase the border-radius value */
        }

        /* You can also adjust the border-radius for the input fields */
        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 20px;
            /* Increase the border-radius value */
            background-color: #7b0323;
        }

        h2 {
            color: white;
        }

        p {
            color: #666;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
        }


        button {
            background-color: rgb(152, 53, 69);
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            font-size: 15px;
            box-sizing: border-box;
            width: -webkit-fill-available;
        }

        button:hover {
            background-color: #7b0323;
        }

        .back-to-login {
            margin-top: 20px;
            color: #333;
        }

        .back-to-login a {
            color: #007bff;
            text-decoration: none;
        }

        .back-to-login a:hover {
            text-decoration: underline;
        }

        /* Add this to your existing CSS */
        .logo {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
            position: absolute;
            margin-top: -167px;
            justify-content: center;
        }

        .profile-container {
            text-align: center;
        }

        .profile-logo {
            max-width: 100%;
            height: 80px;
            margin: 40px;
            border-radius: 20px;
        }
    </style>
</head>

<body>
    <div style="color: black;">
        <div class="profile-container">
            <img src="img/logo.png" alt="Profile Logo" class="profile-logo">
        </div>
        <div class="container">
            <form id="pass" class="forgot-password-form">
                <h2>Forgot Password</h2>
                <input type="tel" id="mobile" name="mobile" placeholder="Phone Number" required>
                <button type="submit">SUBMIT</button>
            </form>
            <div id="message"></div>
        </div>
    </div>
    <!-- Add this script to your HTML file -->
    <script>
        $(document).ready(function() {
            $("#pass").submit(function(e) {
                e.preventDefault();

                var formData = $(this).serialize();

                $.ajax({
                    type: "POST",
                    url: "forgotapi.php",
                    data: formData,
                    success: function(response) {
                        console.log(response);
                        $("#message").html(response);
                        console.log('Before redirection'); // Add this line
                        if (response.indexOf('Number is Registered') !== -1) {
                            window.location.href = "verify.html";
                        }
                    }
                });
            });
        });
    </script>
</body>

</html>