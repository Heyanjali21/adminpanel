<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <title>Signup Page</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .signup-container {
      background-color: #7b0323;
      border-radius: 30px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      width: 300px;
    }

    .signup-container h2 {
      color: white;
    }

    .signup-form {
      margin-top: 20px;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }

    .form-group input {
      width: 100%;
      padding: 8px;
      box-sizing: border-box;
      border-radius: 20px;
      background: #7b0323;
    }

    .form-group button {
      background-color: rgb(152, 53, 69);
      color: #fff;
      padding: 10px;
      border: none;
      border-radius: 20px;
      cursor: pointer;
      font-size: 15px;
      width: -webkit-fill-available;
    }

    .profile-container {
      text-align: center;
    }

    .profile-logo {
      max-width: 100%;
      height: 80px;
      margin: 40px;
      border-radius: 20px;
    }
  </style>
</head>

<body>
  <div style="color: black;">
    <div class="profile-container">
      <img src="img/logo.png" alt="Profile Logo" class="profile-logo">
    </div>
    <div class="signup-container">
      <h2>Sign Up</h2>
      <form class="signup-form" id="signupform">
        <div class="form-group">
          <label for="username" style="color: white;">Username:</label>
          <input type="text" id="name" name="name" required>
        </div>
        <div class="form-group">
          <label for="mobile" style="color: white;">Phone Number:</label>
          <input type="text" id="mobile" name="mobile" required>
        </div>
        <div class="form-group">
          <label for="email" style="color: white;">Email:</label>
          <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
          <label for="password" style="color: white;">Password:</label>
          <input type="password" id="password" name="password" required>
        </div>
        <div class="form-group">
          <label for="Number" style="color: white;">Mpin:</label>
          <input type="text" id="Mpin" name="Mpin" required>
        </div>
        <div class="form-group">
          <button type="submit">Sign Up</button>
        </div>
        <div>
          <p style="color: white; justify-content: center;">Already have an Account? <a href="loginpage.php"
              style="color: white;">Login</a></p>

        </div>
      </form>
      <div id="message"></div>
    </div>
  </div>
  <!-- Add this script in the head or at the end of the body -->
  <script>
    $(document).ready(function(){
      $("#signupform").submit(function(e){
        e.preventDefault();

        var formData = $(this).serialize();

        $.ajax({
          type: "POST",
          url: "signup.php",
          data: formData,
          success: function(response){
            $("#message").html(response);
            if (response.indexOf('register successful') !== -1) {
              window.location.href = "loginpage.php"; 
            }
          }
        });
      });
    });
  </script>
</body>

</html>