<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sgkalyan</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-qh8Xz5g+5+pru3AKbBxyTsvYZJTRs/46g2hghT8cF4vj84Qw4rcq5egxxjczD2hpjli4ItRVr7YqNJo6ikfCA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            overflow-x: hidden;
        }

        .container {
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 0px;
            margin: auto;
            max-width: 400px;
            position: relative;
            text-align: center;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }

        .abc {
            background-color: #702424;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: auto;
            max-width: 400px;
            display: flex;
            align-items: center;
        }

        .back-icon {
            margin-right: 20px;
            cursor: pointer;
        }

        .card {
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 15px;
            margin: 10px;
            width: 30%;
        }

        .card img {
            max-width: 100%;
            max-height: 60px;
            object-fit: contain;
            border-radius: 60%;
            margin-bottom: 10px;
            background-color: #171616;
        }

        .cardd {
            border: 1px solid #ccc;
            border-radius: 20px;
            padding: 15px;
            margin: 10px;
            width: 80%;
        }

        .cardd img {
            max-width: 100%;
            max-height: 60px;
            object-fit: contain;
            border-radius: 60%;
            margin-bottom: 10px;
            background-color: #171616;
        }
    </style>
</head>

<body>
    <div class="abc">
        <span class="back-icon" onclick="goBack()">&#8592;</span>
        <h2>sgkalyan</h2>
    </div>
    <div class="container">
        <div class="card" style="background-color: rgb(253, 253, 162);">
            <a href="singledigit.php"><img src="./img/ludo.jpeg" alt="Image"></a>
            <p>Single Digit</p>
        </div>

        <div class="card" style="background-color: rgb(243, 243, 110);">
        <div>
            <?php
            $apiUrl = 'https://disawar.techwarezen.shop/admin/api-check-game-status';
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            }

            $game_id = isset($_COOKIE['game_id']) ? $_COOKIE['game_id'] : '';
            $tokenData = array(
                "env_type" => "Prod",
                "app_key" => "HbegvJLeKwSFyApopniGHHBTZPocyH",
                "unique_token" => "4AR6tSuQEquKeUL7Uwh1ZnkaJz0vrK",
            );

            $tokenJson = json_encode($tokenData);

            $ch = curl_init($apiUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $tokenJson);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

            $response = curl_exec($ch);
            curl_close($ch);

            // Decode the JSON response
            $responseData = json_decode($response, true);

            // Check the game status
            $gameStatus = isset($responseData['status']) ? $responseData['status'] : '';
            if ($gameStatus == 2) {
                echo '<p>Betting is closed. Click on Jodi Digit.</p>';
            } elseif ($gameStatus == 1) {
                echo '<p><a href="index.php">Open index page</a></p>';
            } else {
                echo '<p>Game status is not recognized.</p>';
            }


            ?>
        </div>
            <img src="./img/ludoo.jpeg" alt="Image">
            <p id="gameStatusText">Jodi Digit</p>
        </div>
        <!-- Second Line -->
        <div class="card" style="background-color: plum;">
            <a href="singlepana.html"><img src="./img/card.png" alt="Image"></a>
            <p>Single Panna</p>
        </div>

        <div class="card" style="background-color: rgb(103, 213, 103);">
            <a href="doublepana.html"><img src="./img/card.png" alt="Image"></a>
            <p>Double Panna</p>
        </div>

        <!-- Third Line -->
        <div class="card" style="background-color: rgb(136, 182, 136);">
            <a href="triplepana.html"><img src="./img/card.png" alt="Image"></a>
            <p>Triple Panna</p>
        </div>

        <div class="card" style="background-color: rgb(151, 151, 206);" id="myCard">
            <img src="./img/card.png" alt="Image">
            <p>Half Sangam</p>
        </div>


        <div class="cardd" style="background-color: rgb(250, 99, 17);">
            <img src="./img/ludo.jpeg" alt="Image">
            <p>Full Sangam</p>
        </div>
    </div>
    <div id="message"></div>

    <script>
        function goBack() {
            window.location.href = 'main.php';
        }
    </script>
</body>

</html>