<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wallet</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-qh8Xz5g+5+pru3AKbBxyTsvYZJTRs/46g2hghT8cF4vj84Qw4rcq5egxxjczD2hpjli4ItRVr7YqNJo6ikfCA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            overflow-x: hidden;
        }

        /* @media only screen and (max-width: 600px) {
            body {
                padding: 0 10px;
            }
        } */

        /* Media query for medium-sized screens */
        @media only screen and (min-width: 601px) and (max-width: 1024px) {
            body {
                padding: 0 30px;
            }
        }

        /* Media query for larger screens */
        @media only screen and (min-width: 1025px) {
            body {
                padding: 0 50px;
            }
        }

        .container {
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 0px;
            margin: auto;
            max-width: 400px;
            position: relative;
        }

        .card-container {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
        }

        .card {
            background-color: white;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 20px;
            margin-bottom: 10px;
            height: 80px;
            width: auto;
            border: 2px solid brown;
        }

        .logo {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
            position: absolute;
            margin-top: -167px;
        }

        .abc {
            background-color: #702424;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: auto;
            max-width: 400px;
        }

        .abc {
            display: flex;
            align-items: center;
        }

        .back-icon {
            margin-right: 20px;
            cursor: pointer;
        }

        .form-group button {
            background-color: rgb(152, 53, 69);
            color: white;
            padding: 10px;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            font-size: 10px;
            width: 60%;
            margin-left: 20%;
            margin-bottom: 100%;
        }

        .con {
            display: flex;
            overflow-x: auto;
            /* Enable horizontal scrolling */
            white-space: nowrap;
            /* Prevent wrapping to next line */
        }

        .card-con {
            display: flex;
            justify-content: space-around;
            /* Adjust as needed */
            align-items: center;
            /* Adjust as needed */
        }

        .cardd {
            background-color: #ffffff;
            border: 2px solid brown;
            border-radius: 8px;
            padding: 10px;
            margin: 10px;
            width: 80px;
            height: 120px;
            margin-top: 30px;
        }

        .cardd img {
            max-width: 100%;
            max-height: 70%;
            object-fit: contain;
            border-radius: 60%;
            margin-bottom: 10px;
            border: 2px solid black;

        }

        .cardd h3 {
            color: black;
            font-size: 10px;
        }

        .containerr {
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 8px;
            position: relative;
            width: 100%;
        }

        .card-conn {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
        }

        .c {
            background-color: white;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 20px;
            margin-bottom: 10px;
            height: 80px;
            width: 100%;
            border: 2px solid brown;
        }

        .card {
            position: relative;
        }

        .refresh-icon {
            position: absolute;
            top: 0;
            right: 0;
            cursor: pointer;
            height: 30px;
            margin-top: 20px;
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <div class="abc">
        <span class="back-icon" onclick="goBack()">&#8592;</span>
        <h2>Wallet</h2>
    </div>

    <!-- for virtical card -->
    <div class="container">
        <div class="card-container">
            <div class="card">
                <img src="./img/refresh.png" alt="Refresh" class="refresh-icon" onclick="fetchWalletAmount()">
                <h3 id="walletAmount">Total Balance</h3>
            </div>
        </div>

        <!-- for horizontal card -->

        <div class="con">
            <div class="card-con">
                <div class="cardd">
                    <img src="./img/transfer.png" alt="Image">
                    <h3>transfer Money</h3>
                </div>
            </div>
            <div class="card-con">
                <div class="cardd">
                    <a href="addfund.html"> <img src="./img/addmoney.png" alt="Image"></a>
                    <h3>Add Money</h3>
                </div>
            </div>
            <div class="card-con">
                <div class="cardd">
                    <a href="withdrawfund.html"><img src="./img/withdraw.png" alt="Image"></a>
                    <h3>withdraw Money</h3>
                </div>
            </div>
            <div class="card-con">
                <div class="cardd">
                    <a href="gpay.html"><img src="./img/gpay.png" alt="Image"></a>
                    <h3>Add GooglePay</h3>
                </div>
            </div>
            <div class="card-con">
                <div class="cardd">
                    <a href="phonepe.html"><img src="./img/phonepe.png" alt="Image"></a>
                    <h3>Add phonepe</h3>
                </div>
            </div>
            <div class="card-con">
                <div class="cardd">
                    <a href="paytm.html"><img src="./img/paytm.png" alt="Image"></a>
                    <h3>Add payTm</h3>
                </div>
            </div>

        </div>
        <div class="card-conn">
            <div class="c">
                <h3>abc</h3>
            </div>
        </div>


    </div>

    <script>
        function goBack() {
            window.location.href = 'main.php';
        }
    </script>


    <script>
        async function fetchWalletAmount() {
            try {
                const response = await fetch('https://disawar.techwarezen.shop/admin/api-user-wallet-balance', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        env_type: 'Prod',
                        app_key: 'HbegvJLeKwSFyApopniGHHBTZPocyH',
                        unique_token: '4AR6tSuQEquKeUL7Uwh1ZnkaJz0vrK',
                    }),
                });
                const data = await response.json();

                const walletAmount = data.wallet_amt;

                document.getElementById('walletAmount').innerText = walletAmount;
            } catch (error) {
                console.error('Error fetching wallet amount:', error);
            }
        }

        function goBack() {
            window.location.href = 'main.php';
        }

        document.addEventListener('DOMContentLoaded', fetchWalletAmount);
    </script>
</body>

</html>