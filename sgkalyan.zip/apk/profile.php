<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-qh8Xz5g+5+pru3AKbBxyTsvYZJTRs/46g2hghT8cF4vj84Qw4rcq5egxxjczD2hpjli4ItRVr7YqNJo6ikfCA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }


        .container {
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 0px;
            margin:  auto;
            max-width: 400px;
            position: relative;
        }


        .card-container {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            /* Arrange cards in a column */
        }

        .card {
            background-color: #6c2121;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 10px;
            border-radius: 20px;
            margin-bottom: 20px;
            /* Adjust the height as needed */
            height: 30px;
        
        }

        .profile-icon {
            font-size: 24px; /* Adjust the size as needed */
            margin-bottom: 20px;
            /* Center the profile icon */
            margin: 0 auto;
        }
        .profile-container {
            text-align: center;
        }

        .profile-logo {
            max-width: 100%;
            height: 80px;
            margin: 40px;
            border-radius: 20px;
        }
        .abc {
            background-color: #702424;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin:  auto;
            max-width: 400px;
        }

        .abc {
            display: flex;
            align-items: center;
        }

        .back-icon {
            margin-right: 20px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="abc">
        <span class="back-icon" onclick="goBack()">&#8592;</span>
        <h2>Profile</h2>
    </div>
    <div class="container">
        <div class="profile-container">
                <div>
                    <?php
                    $apiUrl = 'https://disawar.techwarezen.shop/admin/api-get-profile';

                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    }

                    $uniqueToken = isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '';
                    $tokenData = array(
                        "env_type" => "Prod",
                        "app_key" => "HbegvJLeKwSFyApopniGHHBTZPocyH",
                        "unique_token" => $uniqueToken,
                    );

                    // echo $uniqueToken;
                    $tokenJson = json_encode($tokenData);

                    $ch = curl_init($apiUrl);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $tokenJson);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

                    $response = curl_exec($ch);

                    if ($response === false) {
                        echo '<tr><td colspan="4">Error: Unable to fetch data from the API. cURL error: ' . curl_error($ch) . '</td></tr>';
                    } else {
                        $data = json_decode($response, true);
                        if (isset($data['status']) && $data['status']) {
                            if (isset($data['profile'])) {
                                $resultData = $data['profile'][0];
                    ?>
                              <img src="./img/profile.png" alt="Profile Logo" class="profile-logo">
                                <div> <?php echo $resultData["mobile"]; ?>  </div>
                                <div> <?php echo $resultData["user_name"]; ?> </div>
                    <?php
                            } else {
                                echo '<tr><td colspan="4">Error: Profile key is missing in the API response.</td></tr>';
                            }
                        } else {
                            echo '<tr><td colspan="4">Error: ' . $data['msg'] . '</td></tr>';
                        }
                    }

                    curl_close($ch);
                    ?>
                </div>
        </div>
        <div class="header">
        </div>
        <div class="card-container">
            <div class="card" style="text-align: center; display: flex; align-items: center; justify-content: center;">
                <a href="editpro.html" style="color: rgb(255, 255, 255);" >EDIT PROFILE</a>
            </div>
            <div class="card" style="text-align: center; display: flex; align-items: center; justify-content: center;">
                <a href="changepass.html" style="color: rgb(255, 255, 255);" >CHANGE PASSWORD</a>
            </div>
            <div class="card" style="text-align: center; display: flex; align-items: center; justify-content: center;">
                <a href="contact.html" style="color: rgb(255, 255, 255);" >HELP & SUPPORT</a>
            </div>
            <div class="card" style="text-align: center; display: flex; align-items: center; justify-content: center;">
                <a href="#" id="logoutBtn" style="color: rgb(255, 255, 255);" >LOG OUT</a>
    
            </div>
            <!-- Add more cards as needed -->
        </div>
    </div>

    <!-- for back icon -->
    <script>
        function goBack() {
            window.location.href = 'main.php'; 
        }
    </script>
</body>

</html>
