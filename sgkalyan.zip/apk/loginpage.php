<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <title>Login Page</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .login-container {
      background-color: #7b0323;
      border-radius: 30px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      width: 300px;
    }

    .login-container h2 {
      color: white;
    }

    .login-form {
      margin-top: 20px;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }

    .form-group input {
      width: 100%;
      padding: 8px;
      box-sizing: border-box;
      border-radius: 20px;
      background: #7b0323;
    }

    .form-group button {
      background-color: rgb(152, 53, 69);
      color: white;
      padding: 10px;
      border: none;
      border-radius: 20px;
      cursor: pointer;
      font-size: 15px;
      width: -webkit-fill-available;
    }

    .profile-container {
      text-align: center;
    }

    .profile-logo {
      max-width: 100%;
      height: 80px;
      margin: 40px;
      border-radius: 20px;
    }
  </style>
</head>

<body>
  <div style="color: black;">
    <div class="profile-container">
      <img src="img/logo.png" alt="Profile Logo" class="profile-logo">
    </div>
    <div class="login-container">
      <h2 style="color: white;">Login</h2>
      <form id="loginForm" class="login-form">
        <div class="form-group">
          <label for="mobile" style="color: white;">Phone Number</label>
          <input type="text" id="mobile" name="mobile" required>
        </div>
        <div class="form-group">
          <label for="password" style="color: white;">Password:</label>
          <input type="password" id="password" name="password" required>
        </div>
        <div>
          <h3 style="color: white; margin-left: 150px;"> <a href="fogotpass.php" style="color: white;">forgot password</a></h3>
        </div>
        <div class="form-group">
          <button type="submit">LOGIN NOW</button>
        </div>
        <div>
          <p style="color: white; text-align: center;">
            Don't have an Account? <a href="signupage.php" style="color: white;">Sign Up</a>
          </p>
        </div>
      </form>
      <div id="message"></div>
    </div>
  </div>
  <script>
    $(document).ready(function() {
      $("#loginForm").submit(function(e) {
        e.preventDefault();

        var formData = $(this).serialize();

        $.ajax({
          type: "POST",
          url: "login.php",
          data: formData,
          success: function(response) {
            $("#message").html(response);
            if (response.indexOf('Login successful') !== -1) {

              console.log(response);

              var localDataStore = JSON.parse(response).unique_token;
              localStorage.setItem('localDataStore', localDataStore);

              window.location.href = "main.php";


            }
          }
        });
      });
    });
  </script>


</body>

</html>