<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <!-- ... other head elements ... -->
    <title>main page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: white;
            color: #fff;
            padding: 20px;
            text-align: center;
            position: relative;
        }

        #menu-icon {
            display: none;
            /* Initially hide on larger screens */
            position: absolute;
            top: 20px;
            left: 20px;
            cursor: pointer;
            font-size: 20px;
        }

        .main-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            width: 100%;
            max-width: 400px;
            margin-top: 20px;
        }

        .button {
            background-color: #a14837;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 15px;
            cursor: pointer;
            font-size: 16px;
            flex: 1;
            margin: 0 5px;
        }

        .card-container {
            overflow-y: auto;
            overflow-x: hidden;
            max-height: 300px;
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
            margin-top: 20px;
        }

        /* Hide the scrollbar for webkit (Chrome, Safari) */
        .card-container::-webkit-scrollbar {
            width: 0.5em;
        }

        .card-container::-webkit-scrollbar-thumb {
            background-color: #a14837;
            /* You can change the color to match your design */
            outline: 1px solid #7b0323;
            /* You can change the color to match your design */
        }

        .card-container::-webkit-scrollbar-track {
            background-color: #fff;
            /* You can change the color to match your design */
        }

        .card {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 50px;
            padding: 30px;
            margin-bottom: 10px;
            width: 100%;
            max-width: 300px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            height: 70px;
        }

        .menu {
            display: none;
            flex-direction: column;
            align-items: center;
            position: absolute;
            top: 70px;
            left: 20px;
            background-color: #3498db;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 10px;
        }

        .menu-item {
            color: #fff;
            margin: 5px;
            cursor: pointer;
        }

        .sidepanel {
            height: 100%;
            width: 250px;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #111;
            overflow-x: hidden;
            padding-top: 60px;
            transition: 0.5s;
            overflow-y: auto;
        }


        .sidepanel a {
            padding: 8px 8px 8px 32px;
            text-decoration: none;
            font-size: 20px;
            color: white;
            display: block;
            transition: 0.3s;
            padding: 20px;
        }

        .sidepanel a:hover {
            color: #f1f1f1;
        }

        .sidepanel .closebtn {
            position: absolute;
            top: 0;
            right: 25px;
            font-size: 36px;
        }

        .openbtn {
            font-size: 20px;
            cursor: pointer;
            background-color: #7b0323;
            color: white;
            padding: 10px 15px;
            border: none;
        }

        .openbtn:hover {
            background-color: #444;
        }

        #menu-icon {
            display: none;
            /* Initially hide on larger screens */
            position: absolute;
            top: 20px;
            left: 20px;
            cursor: pointer;
            font-size: 20px;
        }

        .icon-with-text {
            display: flex;
            align-items: center;
        }

        .icon-with-text i {
            margin-right: 10px;
            /* Adjust the margin as needed */
        }

        .profile-logo {
            max-width: 100%;
            height: 60px;
            margin: 14px;
            border-radius: 30px;
            margin-top: auto;
        }

        .profile-container {
            text-align: center;
        }

        .profile-img {
            max-width: 100%;
            height: 80px;
            margin: 40px;
            border-radius: 20px;
        }

        .bell-button {
            background-color: #a14837;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 15px;
            cursor: pointer;
            font-size: 16px;
            margin-left: 270px;
        }

        #mySidepanel {
            background-color: #7b0323;
            overflow-x: hidden;
            overflow-y: auto;

        }

        .btn {
            background-color: #7b0323;
            display: flex;
            justify-content: space-between;
            padding: 0px 10px;
        }

        .video-icon {
            float: right;
            width: 24px;
            height: 24px;
            margin-top: -90px;
        }

        .video-ii {
            display: flex;
            justify-content: center;
            align-items: center;
            ;
            width: 24px;
            height: 24px;
            margin-top: -90px;
            margin-left: 140px;
        }

        .center-text {
            text-align: right;
            margin-top: -70px;
            margin-right: 50px;
        }

        .time {
            text-align: right;
            margin-top: -10px;
            margin-right: 50px;
        }

        .center-textt {
            text-align: right;
            margin-right: 50px;
        }

        .name-ico {
            text-align: left;
            color: #7b0323;
            margin-top: -10px;
        }

        .profile-containerr {
            background-color: #a14837;
            margin-top: -58px;

        }

        .bb {
            padding-top: 50px;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0, 0, 0);
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }

        .modal-content {
            background-color: #a14837;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
        }

        .bttn {
            color: white;
            background-color: #a14837;
            padding: 10px 15px;
            margin: 5px;
            border: none;
            border-radius: 20px;
            cursor: pointer;
        }

        .btt {
            color: white;
            background-color: #7b0323;
            padding: 10px 15px;
            margin: 5px;
            border: none;
            border-radius: 20px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div id="mySidepanel" class="sidepanel">
        <div class="profile-containerr">

            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
            <div id="menu-icon"><i class="fas fa-bars"></i></div>
            <a href="profile.php">
                <div>
                    <?php
                    $apiUrl = 'https://disawar.techwarezen.shop/admin/api-get-profile';

                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    }

                    $uniqueToken =  isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '';
                
                    $tokenData = array(
                        "env_type" => "Prod",
                        "app_key" => "HbegvJLeKwSFyApopniGHHBTZPocyH",
                        "unique_token" => $uniqueToken,
                    );

                    //  echo $uniqueToken;
                    $tokenJson = json_encode($tokenData);

                    $ch = curl_init($apiUrl);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $tokenJson);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

                    $response = curl_exec($ch);

                    if ($response === false) {
                        echo '<tr><td colspan="4">Error: Unable to fetch data from the API. cURL error: ' . curl_error($ch) . '</td></tr>';
                    } else {
                        $data = json_decode($response, true);
                        if (isset($data['status']) && $data['status']) {
                            if (isset($data['profile'])) {
                                $resultData = $data['profile'][0];
                    ?>
                                 <img src="./img/profile.png" alt="Profile Logo" class="profile-logo">
                                <div> <?php echo $resultData["mobile"]; ?>  </div>
                                <div> <?php echo $resultData["user_name"]; ?> </div>
                    <?php
                            } else {
                                echo '<tr><td colspan="4">Error: Profile key is missing in the API response.</td></tr>';
                            }
                        } else {
                            echo '<tr><td colspan="4">Error: ' . $data['msg'] . '</td></tr>';
                        }
                    }

                    curl_close($ch);
                    ?>
                </div>

            </a>

        </div class="bb">
        <a href="main.php" class="icon-with-text"><i class="fas fa-home"></i>Home</a>
        <a href="profile.php" class="icon-with-text"><i class="fas fa-user"></i>My Profile</a>
        <a href="wallet.php" class="icon-with-text"><i class="fas fa-wallet"></i>Wallet</a>
        <a href="winhistory.html" class="icon-with-text"><i class="fas fa-trophy"></i>Win History</a>
        <a href="bidhistory.html" class="icon-with-text"><i class="fas fa-gavel"></i>Bid History</a>
        <a href="play.html" class="icon-with-text"><i class="fas fa-play"></i>How To Play</a>
        <a href="#" class="icon-with-text"><i class="fas fa-star"></i>Games Rates</a>
        <a href="#" class="icon-with-text"><i id="share-icon" class="fas fa-share-alt"></i>Share</a>
        <a href="contact.html" class="icon-with-text"><i class="fas fa-question-circle"></i>Help Center</a>
        <a href="https://play.google.com/store/apps/details?id=your.package.name" class="icon-with-text" target="_blank">
            <i class="fas fa-star"></i>Ratings
        </a>
        <a href="adminnotice.html" class="icon-with-text"><i class="fas fa-bullhorn"></i>Admin Notice</a>
        <a href="#" onclick="openModal()"><button class="bttn">LOGOUT</button></a>

        <!-- Modal -->
        <div id="myModal" class="modal">
            <div class="modal-content">
                <p style="color: white;">Are you sure you want to logout?</p>
                <button id="confirmYes" class="btt">Yes</button>
                <button id="confirmNo" class="btt">No</button>
            </div>
        </div>
        <a href="logout.html" onclick="openModal()"><button class="btn" style="color: white;">LOGOUT</button></a>
    </div>

    <div class="btn">
        <button class="openbtn" onclick="openNav()">☰</button>

        <div class="noti">
            <button class="bell-button bell-icon" id="bellButton"><i class="fas fa-bell"></i></button>
        </div>
    </div>
    <header>
        <div class="profile-container">
            <img src="img/logo.png" alt="Profile Logo" class="profile-img">
        </div>
    </header>

    <div class="main-container">
        <div class="button-container">
            <button class="button button-left" onclick="openContactPage()">CONTACT US</button>
            <button class="button button-left" onclick="play()">HOW TO PLAY</button>
        </div>

        <div class="card-container">
            <?php
            $apiUrl = 'https://disawar.techwarezen.shop/admin/api-get-dashboard-data';
            $selectedDate = "";
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            }
            $tokenData = array(
                "env_type" => "Prod",
                "app_key" => "HbegvJLeKwSFyApopniGHHBTZPocyH",
                "unique_token" => "4AR6tSuQEquKeUL7Uwh1ZnkaJz0vrK"
            );


            $tokenJson = json_encode($tokenData);

            $ch = curl_init($apiUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $tokenJson);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

            $response = curl_exec($ch);

            if ($response === false) {
                echo '<tr><td colspan="4">Error: Unable to fetch data from the API. cURL error: ' . curl_error($ch) . '</td></tr>';
            } else {
                $data = json_decode($response, true);

                if ($data === null || !isset($data['result'])) {
                    echo '<tr><td colspan="4">Error: Failed to parse JSON data or missing "result" data.</td></tr>';
                } else {
                    $resultData = $data['result'];

                    // Pagination logic
                    $perPage = 10;
                    $totalResults = count($resultData);
                    $currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;

                    // Calculate total pages
                    $totalPages = ceil($totalResults / $perPage);

                    // Validate current page
                    if ($currentPage < 1) {
                        $currentPage = 1;
                    } elseif ($currentPage > $totalPages) {
                        $currentPage = $totalPages;
                    }

                    // Iterate over the data and display cards
                    foreach ($resultData as $row) {
                        
            ?>
                        <div class="card">
                            <h5 class="card-title name-ico"><?php echo $row['game_name']; ?></h5>
                            <p class="card-text" style="color: red;"><?php echo $row['msg']; ?></p>
                            <p class="card-text center-text" style="color: green;">Open Bids:
                            <p style="color: green;" class="time"><?php echo $row['open_time']; ?></p>
                            </p>
                            <p class="card-text center-textt" style="color: red;">Close Bids:
                            <p style="color: red;" class="time"><?php echo $row['close_time']; ?></p>
                            </p>
                            <a href="javascript:void(0);" class="video-link" data-msg="<?php echo strtolower($row['msg']); ?>">
                                <img src="./img/video.png" alt="Video Icon" class="video-icon">
                            </a>
                            <img src="./img/alram.png" alt="Video Icon" class="video-ii">
                        </div>
            <?php
                    }
                }
            }

            curl_close($ch);
            ?>
        </div>
    </div>
<!-- for send msg -->
<div id="message"></div>
<!-- for send msg -->
    <script>
        function redirectToPage(msg) {
            console.log('Message:', msg);

            if (msg) {
                if (msg.toLowerCase() === 'market running') {
                    console.log('Redirecting to sgkalyan.php');
                    window.location.href = 'sgkalyan.php';
                } else {
                    console.log('Message does not require redirection.');
                }
            } else {
                console.log('Message not available.');
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            var videoLinks = document.querySelectorAll('.video-link');

            videoLinks.forEach(function(link) {
                link.addEventListener('click', function() {
                    var msg = this.getAttribute('data-msg');
                    redirectToPage(msg);
                });
            });
        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const menuIcon = document.getElementById("menu-icon");
            const mainMenu = document.getElementById("main-menu");

            menuIcon.addEventListener("click", function() {
                mainMenu.style.display = mainMenu.style.display === "none" ? "flex" : "none";
            });

            window.addEventListener("resize", function() {
                if (window.innerWidth > 768) {
                    mainMenu.style.display = "none";
                }
            });
        });
    </script>
    <script>
        var shareIcon = document.getElementById("share-icon");
        shareIcon.addEventListener("click", function() {
            var shareUrl = "main.html";
            var shareText = "Check out this cool app on Satta!";
            var whatsappLink = "whatsapp://send?text=" + encodeURIComponent(shareText + " " + shareUrl);
            var instagramLink = "https://www.instagram.com/share?url=" + encodeURIComponent(shareUrl);
            var facebookLink = "https://www.facebook.com/sharer/sharer.php?u=" + encodeURIComponent(shareUrl);
            var linkedinLink = "https://www.linkedin.com/shareArticle?url=" + encodeURIComponent(shareUrl);
            var telegramLink = "https://t.me/share/url?url=" + encodeURIComponent(shareUrl) + "&text=" + encodeURIComponent(shareText);
            window.open(whatsappLink);
            window.open(instagramLink);
            window.open(facebookLink);
            window.open(linkedinLink);
            window.open(telegramLink);
        });
    </script>

    <script>
        function openContactPage() {
            window.location.href = 'contacthome.html';
        }

        function play() {
            window.location.href = 'play.html';
        }
    </script>
    <script>
        function openNav() {
            document.getElementById("mySidepanel").style.width = "250px";
        }

        function closeNav() {
            document.getElementById("mySidepanel").style.width = "0";
        }
    </script>
    <script>
        function goBackk() {
            window.location.href = 'main.html';
        }
    </script>

    <!-- for buuton -->
    <script>
        document.getElementById("bellButton").addEventListener("click", function() {
            window.location.href = "bell.html";
        });
    </script>


    <!-- for logout -->

    <!-- <script>
        function openModal() {
            console.log("Modal button clicked!");
        }

        function openModal() {
            var modal = document.getElementById("myModal");
            var confirmYesBtn = document.getElementById("confirmYes");
            var confirmNoBtn = document.getElementById("confirmNo");

            modal.style.display = "block";

            confirmYesBtn.onclick = function() {
                window.location.href = "loginpage.php";
            };

            confirmNoBtn.onclick = function() {
                window.location.href = "main.php";
            };

            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            };
        }
    </script> -->
    <script>
    function openModal() {
        $("#myModal").show();
    }

    $("#confirmYes").on("click", function() {
        localStorage.clear();
        window.location.href = "loginpage.php";
    });

    $("#confirmNo").on("click", function() {
        $("#myModal").hide();
    });
</script>


<script>
    $(document).ready(function() {
      $("#loginForm").submit(function(e) {
        e.preventDefault();

        var formData = $(this).serialize();

        $.ajax({
          type: "POST",
          url: "sgkalyanapi.php",
          data: formData,
          success: function(response) {
            $("#message").html(response);
            if (response.indexOf('Login successful') !== -1) {

              console.log(response);

         
            }
          }
        });
      });
    });
  </script>


</body>

</html>