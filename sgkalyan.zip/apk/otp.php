<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Verify OTP</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .otp-container {
      background-color: #7b0323;
      border-radius: 30px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      width: 300px;
    }

    .otp-container h2 {
      color: white;
    }

    .otp-form {
      margin-top: 20px;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
      color: white;
    }

    .form-group input {
      width: 100%;
      padding: 8px;
      box-sizing: border-box;
      border-radius: 20px;
      background: #7b0323;
    }

    .form-group button {
      background-color: rgb(152, 53, 69);
      color: #fff;
      padding: 10px;
      border: none;
      border-radius: 20px;
      cursor: pointer;
      font-size: 15px;
      width: -webkit-fill-available;
    }

    .otp-verification {
      margin-top: 20px;
      display: none; 
    }

    .otp-verification label {
      color: white;
    }
  </style>
</head>

<body>
  <div class="otp-container">
    <h2>Verify OTP</h2>
    <form class="otp-form" id="sendOTPForm">
      <div class="form-group">
        <label for="mobile">Phone Number:</label>
        <input type="text" id="mobile" name="mobile" placeholder="Enter your otp" required>
      </div>
      <div class="form-group">
        <button type="button" onclick="sendOTP()">Send OTP</button>
      </div>
    </form>
    </div>
   <script>
    $(document).ready(function(){
      $("#sendOTPForm").submit(function(e){
        e.preventDefault();

        var formData = $(this).serialize();

        $.ajax({
          type: "POST",
          url: "verify.html",
          data: formData,
          success: function(response){
            $("#message").html(response);
          }
        });
      });
    });
  </script>
</body>

</html>
