<?php
$username = $_POST['name'];
$email = $_POST['email'];
$envType = 'Prod';
$appKey = 'HbegvJLeKwSFyApopniGHHBTZPocyH';


$uniqueToken =  isset($_COOKIE['localDataStore']) ? $_COOKIE['localDataStore'] : '';
$data = [
    'user_name' => $username,
    'email' => $email,
    'unique_token' => $uniqueToken,
    "env_type" => $envType,
     'app_key' =>$appKey
];


$jsonData = json_encode($data);

// Set the API endpoint URL
$apiUrl = 'https://disawar.techwarezen.shop/admin/api-profile-update';

// Initialize cURL session
$ch = curl_init($apiUrl);

// Set cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Content-Length: ' . strlen($jsonData),
]);

// Execute cURL session and get the response
$response = curl_exec($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo 'Curl error: ' . curl_error($ch);
}

// Close cURL session
curl_close($ch);

// Display the API response
echo $response;
?>
