<?php

// Get user input from the POST request
$mobile = $_POST['Number'];
// Additional parameters
$envType = 'Prod';
$appKey = 'HbegvJLeKwSFyApopniGHHBTZPocyH';
$uniqueToken = '4AR6tSuQEquKeUL7Uwh1ZnkaJz0vrK';

// Prepare the data to be sent, including additional parameters
$data = [
    'mobile' => $phoneNumber,
    'env_type' => $envType,
    'app_key' => $appKey,
    'unique_token' => $uniqueToken,
    
];

// Convert data to JSON format
$jsonData = json_encode($data);

// Set the API endpoint URL
$apiUrl = 'https://disawar.techwarezen.shop/admin/api-forgot-password';

// Initialize cURL session
$ch = curl_init($apiUrl);

// Set cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Content-Length: ' . strlen($jsonData),
]);

// Execute cURL session and get the response
$response = curl_exec($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo 'Curl error: ' . curl_error($ch);
}

// Close cURL session
curl_close($ch);

// Display the API response
echo $response;
?>
