<?php

// Get the requested page from the URL
$requestedPage = isset($_GET['page']) ? $_GET['page'] : 'home';

// Define allowed pages
$allowedPages = ['home', 'login', 'signup'];

// Check if the requested page is allowed, if not, redirect to home
if (!in_array($requestedPage, $allowedPages)) {
    $requestedPage = 'home';
}

// Include the header or any common content
include 'views/header.php';

// Include the requested page
include 'views/' . $requestedPage . '.php';

// Include the footer or any common content
include 'views/footer.php';
?>
